@echo off
setlocal enabledelayedexpansion
title KatanaDreams CDI Builder

set "MUSIC_DIR=Put_Your_Music_Here"
set "TOOLS_DIR=tools"
set "TEMP_ISO=temp.iso"
set "OUTPUT_CDI=KatanaDreams_Custom.cdi"
set "MAX_SIZE_MB=700"
set /a MAX_SIZE_BYTES=734003200

echo Starting KatanaDreams CDI Builder...
echo.

if not exist "%MUSIC_DIR%" (
    mkdir "%MUSIC_DIR%"
    echo Error: Folder "%MUSIC_DIR%" was missing and has been created.
    echo Please put your music files inside and run this script again.
    goto END
)

if not exist "%TOOLS_DIR%\1ST_READ.BIN" goto MISSING_FILES
if not exist "%TOOLS_DIR%\IP.BIN" goto MISSING_FILES
if not exist "%TOOLS_DIR%\mkisofs.exe" goto MISSING_FILES
if not exist "%TOOLS_DIR%\cdi4dc.exe" goto MISSING_FILES

echo Checking folder contents...
set "FOLDER_SIZE=0"
set "FILE_COUNT=0"

for /R "%MUSIC_DIR%" %%I in (*) do (
    set /a FOLDER_SIZE+=%%~zI
    set /a FILE_COUNT+=1
)

if !FILE_COUNT! EQU 0 (
    echo Error: The "%MUSIC_DIR%" folder is empty.
    echo Please put your music files inside and run this script again.
    goto END
)

set /a FOLDER_SIZE_MB=FOLDER_SIZE / 1048576
echo Found !FILE_COUNT! files. Current size: !FOLDER_SIZE_MB! MB (Limit: %MAX_SIZE_MB% MB)

if !FOLDER_SIZE! GTR %MAX_SIZE_BYTES% (
    echo Error: Folder size exceeds the %MAX_SIZE_MB% MB limit.
    echo Please remove some files.
    goto END
)
echo.
echo Preparing files...
if exist "build_temp" rd /s /q "build_temp"
mkdir "build_temp"
mkdir "build_temp\music"

copy "%TOOLS_DIR%\1ST_READ.BIN" "build_temp\" >nul
copy "%TOOLS_DIR%\IP.BIN" "build_temp\" >nul
xcopy "%MUSIC_DIR%\*" "build_temp\music\" /E /H /C /I /Y >nul

echo Creating ISO...
"%TOOLS_DIR%\mkisofs.exe" -C 0,11702 -V KatanaDreams -G "build_temp\IP.BIN" -r -J -l -o "%TEMP_ISO%" "build_temp" >nul 2>&1

echo Converting to CDI...
"%TOOLS_DIR%\cdi4dc.exe" "%TEMP_ISO%" "%OUTPUT_CDI%" >nul 2>&1

echo Cleaning up...
if exist "build_temp" rd /s /q "build_temp"
if exist "%TEMP_ISO%" del /q "%TEMP_ISO%"

echo.
if exist "%OUTPUT_CDI%" (
    echo Success: %OUTPUT_CDI% created.
) else (
    echo Error: Image creation failed.
)
goto END

:MISSING_FILES
echo Error: Required tools or BIN files are missing in the "%TOOLS_DIR%" folder.

:END
echo.
pause
exit /b